// apps/web/src/App.tsx
import { Routes, Route } from 'react-router-dom';
import { AppLayout }   from './components/layout/AppLayout';
import { HomePage }    from './pages/HomePage';
import { DiscoverPage }from './pages/DiscoverPage';
import { TrackPage }   from './pages/TrackPage';
import { ArtistPage }  from './pages/ArtistPage';
import { UploadPage }  from './pages/UploadPage';
import { LoginPage }   from './pages/LoginPage';
import { RegisterPage }from './pages/RegisterPage';

export default function App() {
  return (
    <Routes>
      <Route path="/login"    element={<LoginPage />} />
      <Route path="/register" element={<RegisterPage />} />
      <Route element={<AppLayout />}>
        <Route index            element={<HomePage />} />
        <Route path="/discover" element={<DiscoverPage />} />
        <Route path="/upload"   element={<UploadPage />} />
        <Route path="/track/:id"   element={<TrackPage />} />
        <Route path="/artist/:username" element={<ArtistPage />} />
      </Route>
    </Routes>
  );
}
