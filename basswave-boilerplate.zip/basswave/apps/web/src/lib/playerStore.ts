// apps/web/src/lib/playerStore.ts
import { create } from 'zustand';

export interface Track {
  id:       string;
  title:    string;
  artist:   { displayName: string; username: string };
  audioUrl: string;
  coverUrl: string | null;
  duration: number;
  genre:    string;
  bpm:      number | null;
}

interface PlayerState {
  queue:      Track[];
  currentIdx: number;
  playing:    boolean;
  progress:   number;   // 0-1
  volume:     number;   // 0-1

  // actions
  play:       (track: Track, queue?: Track[]) => void;
  toggle:     () => void;
  next:       () => void;
  prev:       () => void;
  seek:       (progress: number) => void;
  setVolume:  (v: number) => void;
  setProgress:(p: number) => void;
}

export const usePlayerStore = create<PlayerState>((set, get) => ({
  queue:      [],
  currentIdx: 0,
  playing:    false,
  progress:   0,
  volume:     0.8,

  play: (track, queue) => {
    const q   = queue ?? [track];
    const idx = q.findIndex(t => t.id === track.id);
    set({ queue: q, currentIdx: idx, playing: true, progress: 0 });
  },

  toggle: () => set(s => ({ playing: !s.playing })),

  next: () => set(s => {
    const next = (s.currentIdx + 1) % s.queue.length;
    return { currentIdx: next, progress: 0, playing: true };
  }),

  prev: () => set(s => {
    if (s.progress > 0.05) return { progress: 0 };
    const prev = (s.currentIdx - 1 + s.queue.length) % s.queue.length;
    return { currentIdx: prev, progress: 0, playing: true };
  }),

  seek:        (progress)  => set({ progress }),
  setVolume:   (volume)    => set({ volume }),
  setProgress: (progress)  => set({ progress }),
}));

export const currentTrack = (s: PlayerState) => s.queue[s.currentIdx] ?? null;
