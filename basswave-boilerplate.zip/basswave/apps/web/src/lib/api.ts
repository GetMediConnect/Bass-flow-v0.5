// apps/web/src/lib/api.ts
import axios from 'axios';

export const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || 'http://localhost:3001',
});

// Auto-attach JWT
api.interceptors.request.use(cfg => {
  const token = localStorage.getItem('bw_token');
  if (token) cfg.headers.Authorization = `Bearer ${token}`;
  return cfg;
});

// ── Track API ────────────────────────────────────────────
export const tracksApi = {
  list:    (params?: Record<string, string>) => api.get('/api/tracks', { params }).then(r => r.data),
  get:     (id: string)                      => api.get(`/api/tracks/${id}`).then(r => r.data),
  create:  (data: unknown)                   => api.post('/api/tracks', data).then(r => r.data),
  delete:  (id: string)                      => api.delete(`/api/tracks/${id}`).then(r => r.data),
  like:    (id: string)                      => api.post(`/api/tracks/${id}/like`).then(r => r.data),
  comment: (id: string, body: string, timestamp?: number) =>
    api.post(`/api/tracks/${id}/comments`, { body, timestamp }).then(r => r.data),
};

// ── Upload API ───────────────────────────────────────────
export const uploadsApi = {
  audio: (file: File) => {
    const fd = new FormData(); fd.append('file', file);
    return api.post<{ url: string }>('/api/uploads/audio', fd).then(r => r.data.url);
  },
  cover: (file: File) => {
    const fd = new FormData(); fd.append('file', file);
    return api.post<{ url: string }>('/api/uploads/cover', fd).then(r => r.data.url);
  },
};

// ── Auth API ─────────────────────────────────────────────
export const authApi = {
  register: (data: unknown) => api.post('/api/auth/register', data).then(r => r.data),
  login:    (data: unknown) => api.post('/api/auth/login',    data).then(r => r.data),
  me:       ()              => api.get('/api/users/me/profile').then(r => r.data),
};
