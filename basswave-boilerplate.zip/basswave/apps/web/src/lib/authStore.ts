// apps/web/src/lib/authStore.ts
import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { authApi } from './api';

interface User {
  id: string; username: string; displayName: string;
  avatarUrl: string | null; country: string | null; role: string;
}
interface AuthState {
  token: string | null;
  user:  User  | null;
  login:    (email: string, password: string) => Promise<void>;
  register: (data: unknown) => Promise<void>;
  logout:   () => void;
  loadMe:   () => Promise<void>;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      token: null,
      user:  null,

      login: async (email, password) => {
        const { token, user } = await authApi.login({ email, password });
        localStorage.setItem('bw_token', token);
        set({ token, user });
      },

      register: async (data) => {
        const { token, user } = await authApi.register(data);
        localStorage.setItem('bw_token', token);
        set({ token, user });
      },

      logout: () => {
        localStorage.removeItem('bw_token');
        set({ token: null, user: null });
      },

      loadMe: async () => {
        try {
          const user = await authApi.me();
          set({ user });
        } catch { /* token expired */ }
      },
    }),
    { name: 'bw-auth', partialize: (s) => ({ token: s.token, user: s.user }) }
  )
);
