// apps/web/src/components/tracks/TrackCard.tsx
import { useState } from 'react';
import { Link } from 'react-router-dom';
import { usePlayerStore } from '../../lib/playerStore';
import { tracksApi } from '../../lib/api';
import { WaveformCanvas } from '../player/WaveformCanvas';
import styles from './TrackCard.module.css';

interface Props { track: any; queue?: any[]; }

const GENRE_COLORS: Record<string, [string, string]> = {
  LIQUID_DNB:  ['#33e4ff','#7b5cff'],
  NEUROFUNK:   ['#ff3366','#7b5cff'],
  TECH_DNB:    ['#ffaa00','#ff3366'],
  DARKSTEP:    ['#7b5cff','#33e4ff'],
  JUMP_UP:     ['#ff6b35','#ffaa00'],
  ROLLERS:     ['#4cffb2','#33e4ff'],
  HALFSTEP:    ['#33e4ff','#4cffb2'],
  OTHER:       ['#9ba0bd','#6b7090'],
};

export function TrackCard({ track, queue }: Props) {
  const store    = usePlayerStore();
  const [liked, setLiked]   = useState<boolean>(track.likedByMe ?? false);
  const [likes, setLikes]   = useState<number>(track._count?.likes ?? 0);
  const isPlaying = store.playing && store.queue[store.currentIdx]?.id === track.id;
  const colors  = GENRE_COLORS[track.genre] ?? ['#33e4ff','#7b5cff'];

  async function handleLike() {
    try {
      const res = await tracksApi.like(track.id);
      setLiked(res.liked);
      setLikes(l => res.liked ? l+1 : l-1);
    } catch {}
  }

  function handlePlay() {
    const q = queue ?? [track];
    if (store.queue[store.currentIdx]?.id === track.id) {
      store.toggle();
    } else {
      store.play(track, q);
    }
  }

  function handleWfSeek(p: number) {
    store.play(track, queue ?? [track]);
    store.seek(p);
  }

  return (
    <article className={styles.card}>
      <div className={styles.top}>
        <div className={styles.cover} style={{ background: `linear-gradient(135deg,${colors[0]},${colors[1]})` }}>
          {track.coverUrl && <img src={track.coverUrl} alt={track.title} />}
        </div>
        <div className={styles.meta}>
          <Link to={`/track/${track.id}`} className={styles.title}>{track.title}</Link>
          <Link to={`/artist/${track.artist?.username}`} className={styles.artist}>
            {track.artist?.displayName}
          </Link>
          <div className={styles.tags}>
            <span className={styles.tag}>{track.genre?.replace('_',' ')}</span>
            {track.bpm && <span className={`${styles.tag} ${styles.bpm}`}>{track.bpm} BPM</span>}
            {track.country && <span className={`${styles.tag} ${styles.country}`}>{track.country}</span>}
          </div>
        </div>
      </div>

      <WaveformCanvas
        peaks={track.waveformData}
        progress={isPlaying ? store.progress : 0}
        colors={colors}
        onSeek={handleWfSeek}
        height={28}
      />

      <div className={styles.actions}>
        <div className={styles.left}>
          <button
            className={`${styles.playBtn} ${isPlaying ? styles.playing : ''}`}
            onClick={handlePlay}
          >
            {isPlaying && store.playing ? '⏸' : '▶'}
          </button>
          <Link to={`/track/${track.id}`} className={styles.ghost}>Szczegóły</Link>
        </div>
        <div className={styles.right}>
          <button
            className={`${styles.ghost} ${liked ? styles.liked : ''}`}
            onClick={handleLike}
          >
            {liked ? '♥' : '♡'} {likes}
          </button>
          <span className={styles.ghost}>
            💬 {track._count?.comments ?? 0}
          </span>
        </div>
      </div>
    </article>
  );
}
