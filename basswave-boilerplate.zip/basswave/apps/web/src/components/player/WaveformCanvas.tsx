// apps/web/src/components/player/WaveformCanvas.tsx
import { useEffect, useRef } from 'react';

interface Props {
  peaks?:    number[];   // 0-1 normalised, from DB waveformData
  progress:  number;     // 0-1
  colors:    [string, string];
  onSeek?:   (p: number) => void;
  height?:   number;
}

// Fallback synthetic peaks when no real data yet
function syntheticPeaks(n: number): number[] {
  return Array.from({ length: n }, (_, i) =>
    (Math.sin(i * 0.28) * 0.35 + Math.sin(i * 0.11) * 0.3 + 0.35)
  );
}

export function WaveformCanvas({ peaks, progress, colors, onSeek, height = 22 }: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const w   = canvas.parentElement?.clientWidth ?? 400;
    canvas.width  = w;
    canvas.height = height;
    const ctx = canvas.getContext('2d')!;
    ctx.clearRect(0, 0, w, height);

    const data = peaks && peaks.length > 0 ? peaks : syntheticPeaks(Math.floor(w / 3));
    const bars = data.length;

    for (let i = 0; i < bars; i++) {
      const x      = (i / bars) * w;
      const barW   = Math.max(1, (w / bars) - 1);
      const played = (i / bars) < progress;
      const ht     = data[i] * height * 0.9;

      if (played) {
        const g = ctx.createLinearGradient(0, 0, 0, height);
        g.addColorStop(0, colors[0]);
        g.addColorStop(1, colors[1]);
        ctx.fillStyle    = g;
        ctx.globalAlpha  = 0.9;
      } else {
        ctx.fillStyle   = 'rgba(255,255,255,0.12)';
        ctx.globalAlpha = 1;
      }
      ctx.fillRect(x, (height - ht) / 2, barW, ht);
    }
    ctx.globalAlpha = 1;

    // playhead
    if (progress > 0) {
      const px = progress * w;
      ctx.save();
      ctx.shadowColor = 'rgba(255,255,255,0.8)';
      ctx.shadowBlur  = 5;
      ctx.fillStyle   = 'rgba(255,255,255,0.9)';
      ctx.fillRect(px - 1, 0, 2, height);
      ctx.restore();
    }
  }, [peaks, progress, colors, height]);

  function handleClick(e: React.MouseEvent<HTMLCanvasElement>) {
    if (!onSeek || !canvasRef.current) return;
    const rect = canvasRef.current.getBoundingClientRect();
    onSeek((e.clientX - rect.left) / rect.width);
  }

  return (
    <canvas
      ref={canvasRef}
      style={{ width: '100%', height, cursor: onSeek ? 'pointer' : 'default', display: 'block' }}
      onClick={handleClick}
    />
  );
}
