// apps/web/src/components/player/PlayerBar.tsx
import { useRef, useEffect } from 'react';
import { usePlayerStore, currentTrack } from '../../lib/playerStore';
import { WaveformCanvas } from './WaveformCanvas';
import styles from './PlayerBar.module.css';

export function PlayerBar() {
  const store   = usePlayerStore();
  const track   = usePlayerStore(currentTrack);
  const barRef  = useRef<HTMLDivElement>(null);

  function handleProgressClick(e: React.MouseEvent<HTMLDivElement>) {
    if (!barRef.current) return;
    const rect = barRef.current.getBoundingClientRect();
    store.seek((e.clientX - rect.left) / rect.width);
  }

  const cur = track ? Math.round(store.progress * track.duration) : 0;

  return (
    <div className={styles.player}>
      <div className={styles.glow} />

      {/* Cover */}
      <div className={styles.cover}>
        {track?.coverUrl
          ? <img src={track.coverUrl} alt={track.title} />
          : <div className={styles.coverFallback} />}
      </div>

      {/* Info */}
      <div className={styles.info}>
        <div className={styles.title}>{track?.title ?? '—'}</div>
        <div className={styles.artist}>{track?.artist.displayName ?? '—'}</div>
      </div>

      {/* Progress + waveform */}
      <div className={styles.main}>
        <div className={styles.waveRow}>
          {track && (
            <WaveformCanvas
              peaks={track.waveformData as number[] | undefined}
              progress={store.progress}
              colors={['#33e4ff','#7b5cff']}
              onSeek={store.seek}
            />
          )}
        </div>
        <div
          className={styles.progressBar}
          ref={barRef}
          onClick={handleProgressClick}
        >
          <div
            className={styles.progressFill}
            style={{ width: `${store.progress * 100}%` }}
          />
        </div>
        <div className={styles.timeRow}>
          <span>{fmt(cur)}</span>
          <span>{track ? fmt(track.duration) : '—'}</span>
        </div>
      </div>

      {/* Controls */}
      <div className={styles.controls}>
        <button className={styles.btn} onClick={store.prev}>⏮</button>
        <button className={`${styles.btn} ${styles.primary}`} onClick={store.toggle}>
          {store.playing ? '⏸' : '▶'}
        </button>
        <button className={styles.btn} onClick={store.next}>⏭</button>
      </div>

      {/* Visualiser */}
      <div className={`${styles.vis} ${store.playing ? '' : styles.paused}`}>
        {[...Array(7)].map((_,i) => <span key={i} />)}
      </div>

      {/* Volume */}
      <div className={styles.vol}>
        <span>🔊</span>
        <input
          type="range" min={0} max={1} step={0.01}
          value={store.volume}
          onChange={e => store.setVolume(Number(e.target.value))}
          className={styles.volSlider}
        />
      </div>
    </div>
  );
}

function fmt(s: number) {
  s = Math.max(0, Math.round(s));
  return `${Math.floor(s/60)}:${String(s%60).padStart(2,'0')}`;
}
