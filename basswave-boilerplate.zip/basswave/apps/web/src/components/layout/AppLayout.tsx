// apps/web/src/components/layout/AppLayout.tsx
import { Outlet, NavLink, useNavigate } from 'react-router-dom';
import { useAuthStore } from '../../lib/authStore';
import { useAudioPlayer } from '../../hooks/useAudioPlayer';
import { PlayerBar } from '../player/PlayerBar';
import styles from './AppLayout.module.css';

const NAV = [
  { to: '/',         icon: '🏠', label: 'Home' },
  { to: '/discover', icon: '✨', label: 'Odkrywaj' },
  { to: '/upload',   icon: '⬆️', label: 'Wgraj track' },
];

const NAV_LIVE = [
  { to: '#', icon: '📻', label: 'Radio 24/7', live: true },
  { to: '#', icon: '📅', label: 'Wydarzenia' },
];

export function AppLayout() {
  useAudioPlayer(); // mounts audio engine once
  const { user, logout } = useAuthStore();
  const navigate = useNavigate();

  return (
    <div className={styles.app}>
      {/* ── Header ── */}
      <header className={styles.header}>
        <div className={styles.logo}>
          <div className={styles.logoMark} />
          <span>BassWave</span>
        </div>
        <input
          className={styles.search}
          placeholder="Szukaj tracków, artystów…"
          onKeyDown={e => {
            if (e.key === 'Enter') {
              navigate(`/discover?q=${encodeURIComponent((e.target as HTMLInputElement).value)}`);
            }
          }}
        />
        <div className={styles.headerRight}>
          {user ? (
            <>
              <span className={styles.username}>@{user.username}</span>
              <button className={styles.avatarBtn} onClick={logout}
                title="Wyloguj">{user.displayName[0].toUpperCase()}</button>
            </>
          ) : (
            <button className={styles.loginBtn} onClick={() => navigate('/login')}>Zaloguj się</button>
          )}
        </div>
      </header>

      {/* ── Sidebar ── */}
      <aside className={styles.sidebar}>
        <div className={styles.navLabel}>Nawigacja</div>
        <nav>
          {NAV.map(n => (
            <NavLink key={n.to} to={n.to} end={n.to==='/'} className={({isActive}) =>
              `${styles.navItem} ${isActive ? styles.active : ''}`}>
              <span className={styles.ico}>{n.icon}</span>
              <span>{n.label}</span>
            </NavLink>
          ))}
        </nav>

        <div className={styles.navLabel}>Na żywo</div>
        <nav>
          {NAV_LIVE.map(n => (
            <a key={n.label} href={n.to} className={styles.navItem}>
              <span className={styles.ico}>{n.icon}</span>
              <span>{n.label}</span>
              {n.live && <span className={styles.liveDot} />}
            </a>
          ))}
        </nav>

        <div className={styles.navLabel}>Dla labeli</div>
        <nav>
          <a href="#" className={styles.navItem}><span className={styles.ico}>🏷️</span><span>Panel labela</span></a>
          <a href="#" className={styles.navItem}><span className={styles.ico}>📈</span><span>Analityka</span></a>
        </nav>
      </aside>

      {/* ── Main ── */}
      <main className={styles.main}>
        <Outlet />
      </main>

      {/* ── Player ── */}
      <PlayerBar />
    </div>
  );
}
