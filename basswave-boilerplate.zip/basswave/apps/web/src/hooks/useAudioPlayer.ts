// apps/web/src/hooks/useAudioPlayer.ts
import { useEffect, useRef, useCallback } from 'react';
import { usePlayerStore, currentTrack } from '../lib/playerStore';

/**
 * Connects Zustand player store to a real HTMLAudioElement.
 * Mount once at app root (inside AppLayout).
 */
export function useAudioPlayer() {
  const audioRef  = useRef<HTMLAudioElement | null>(null);
  const store     = usePlayerStore();
  const track     = usePlayerStore(currentTrack);

  // Create audio element once
  useEffect(() => {
    const audio = new Audio();
    audio.volume = store.volume;
    audio.preload = 'metadata';
    audioRef.current = audio;

    // Sync progress to store every 250ms
    const tick = setInterval(() => {
      if (!audio.duration) return;
      usePlayerStore.getState().setProgress(audio.currentTime / audio.duration);
    }, 250);

    audio.addEventListener('ended', () => {
      usePlayerStore.getState().next();
    });

    return () => {
      clearInterval(tick);
      audio.pause();
      audio.src = '';
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Load new src when track changes
  useEffect(() => {
    const audio = audioRef.current;
    if (!audio || !track) return;
    audio.src = track.audioUrl;
    audio.load();
    if (store.playing) audio.play().catch(() => {});
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [track?.id]);

  // Play / pause
  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;
    if (store.playing) {
      audio.play().catch(() => {});
    } else {
      audio.pause();
    }
  }, [store.playing]);

  // Volume
  useEffect(() => {
    if (audioRef.current) audioRef.current.volume = store.volume;
  }, [store.volume]);

  // Seek
  const seek = useCallback((progress: number) => {
    const audio = audioRef.current;
    if (!audio || !audio.duration) return;
    audio.currentTime = progress * audio.duration;
    store.seek(progress);
  }, [store]);

  return { seek };
}

/* ── Waveform decoder (runs once on upload) ──────────────
   Decodes an audio File into ~200 normalised peaks (0-1).
   Call this in UploadPage before submitting.
*/
export async function extractWaveformPeaks(file: File, numPeaks = 200): Promise<number[]> {
  const ctx    = new (window.AudioContext || (window as any).webkitAudioContext)();
  const buffer = await file.arrayBuffer();
  const decoded = await ctx.decodeAudioData(buffer);
  await ctx.close();

  const raw    = decoded.getChannelData(0); // mono L
  const step   = Math.floor(raw.length / numPeaks);
  const peaks: number[] = [];

  for (let i = 0; i < numPeaks; i++) {
    let max = 0;
    for (let j = 0; j < step; j++) {
      const v = Math.abs(raw[i * step + j] || 0);
      if (v > max) max = v;
    }
    peaks.push(max);
  }
  // Normalise to 0-1
  const maxVal = Math.max(...peaks, 0.001);
  return peaks.map(p => p / maxVal);
}
