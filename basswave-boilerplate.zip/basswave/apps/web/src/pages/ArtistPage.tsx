// apps/web/src/pages/ArtistPage.tsx
import { useParams } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { tracksApi } from '../lib/api';
import { api } from '../lib/api';
import { useAuthStore } from '../lib/authStore';
import { TrackCard } from '../components/tracks/TrackCard';
import styles from './ArtistPage.module.css';

export function ArtistPage() {
  const { username } = useParams<{ username: string }>();
  const { user: me } = useAuthStore();
  const qc = useQueryClient();

  const { data: artist, isLoading } = useQuery({
    queryKey: ['artist', username],
    queryFn: () => api.get(`/api/users/${username}`).then(r => r.data),
  });

  const followMutation = useMutation({
    mutationFn: () => api.post(`/api/users/${artist.id}/follow`).then(r => r.data),
    onSuccess:  () => qc.invalidateQueries({ queryKey: ['artist', username] }),
  });

  if (isLoading) return <div className={styles.loading}>Ładowanie…</div>;
  if (!artist)   return <div className={styles.loading}>Nie znaleziono artysty.</div>;

  const isMe = me?.id === artist.id;

  return (
    <div className={styles.page}>
      {/* Header */}
      <div className={styles.hero}>
        <div className={styles.avatar}>
          {artist.avatarUrl
            ? <img src={artist.avatarUrl} alt={artist.displayName} />
            : <span>{artist.displayName[0].toUpperCase()}</span>}
        </div>
        <div className={styles.heroInfo}>
          <h1>{artist.displayName}</h1>
          <div className={styles.handle}>@{artist.username}
            {artist.country && <span className={styles.country}>{artist.country}</span>}
          </div>
          {artist.bio && <p className={styles.bio}>{artist.bio}</p>}
          <div className={styles.stats}>
            <div className={styles.stat}>
              <strong>{artist._count?.tracks ?? 0}</strong>
              <span>tracki</span>
            </div>
            <div className={styles.stat}>
              <strong>{artist._count?.followers ?? 0}</strong>
              <span>obserwujący</span>
            </div>
            <div className={styles.stat}>
              <strong>{artist._count?.following ?? 0}</strong>
              <span>obserwuje</span>
            </div>
          </div>
        </div>
        {!isMe && me && (
          <button
            className={styles.followBtn}
            onClick={() => followMutation.mutate()}
            disabled={followMutation.isPending}
          >
            {followMutation.isPending ? '…' : '+ Obserwuj'}
          </button>
        )}
      </div>

      {/* Tracks */}
      <div className={styles.sectionHead}>
        <h2>Tracki</h2>
        <span className={styles.sub}>{artist.tracks?.length ?? 0} utworów</span>
      </div>

      {artist.tracks?.length === 0 ? (
        <div className={styles.empty}>Brak publicznych tracków.</div>
      ) : (
        <div className={styles.grid}>
          {artist.tracks?.map((t: any) => (
            <TrackCard key={t.id} track={{ ...t, artist }} queue={artist.tracks} />
          ))}
        </div>
      )}
    </div>
  );
}
