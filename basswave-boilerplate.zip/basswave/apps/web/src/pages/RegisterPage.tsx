// apps/web/src/pages/RegisterPage.tsx
import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuthStore } from '../lib/authStore';
import styles from './AuthPage.module.css';

export function RegisterPage() {
  const navigate = useNavigate();
  const { register } = useAuthStore();
  const [form, setForm] = useState({ email:'', password:'', username:'', displayName:'', country:'PL' });
  const [error, setError]   = useState('');
  const [loading, setLoading] = useState(false);
  const f = (k: string) => (e: React.ChangeEvent<HTMLInputElement>) =>
    setForm(prev => ({ ...prev, [k]: e.target.value }));

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true); setError('');
    try {
      await register(form);
      navigate('/');
    } catch (err: any) {
      setError(err.response?.data?.error ?? 'Błąd rejestracji. Spróbuj ponownie.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className={styles.page}>
      <div className={styles.card}>
        <div className={styles.logo}>
          <div className={styles.logoMark} />
          <span>BassWave</span>
        </div>
        <h1>Dołącz do sceny</h1>
        <p className={styles.sub}>Stwórz konto i wgraj swój pierwszy track</p>

        <form onSubmit={handleSubmit} className={styles.form}>
          <div className={styles.row}>
            <label className={styles.field}>
              <span>Imię / Nick artystyczny</span>
              <input value={form.displayName} onChange={f('displayName')}
                placeholder="DJ Maduki" required autoFocus />
            </label>
            <label className={styles.field}>
              <span>Username</span>
              <input value={form.username} onChange={f('username')}
                placeholder="djmaduki" pattern="[a-z0-9_]+" title="Tylko małe litery, cyfry i _" required />
            </label>
          </div>
          <label className={styles.field}>
            <span>Email</span>
            <input type="email" value={form.email} onChange={f('email')}
              placeholder="dj@basswave.io" required />
          </label>
          <div className={styles.row}>
            <label className={styles.field}>
              <span>Hasło (min. 8 znaków)</span>
              <input type="password" value={form.password} onChange={f('password')}
                placeholder="••••••••" minLength={8} required />
            </label>
            <label className={styles.field}>
              <span>Kraj</span>
              <input value={form.country} onChange={f('country')}
                maxLength={2} placeholder="PL" style={{ textTransform:'uppercase' }} />
            </label>
          </div>

          {error && <div className={styles.error}>{error}</div>}

          <button type="submit" className={styles.submitBtn} disabled={loading}>
            {loading ? 'Tworzenie konta…' : '🎛 Stwórz konto'}
          </button>
        </form>

        <p className={styles.footer}>
          Masz już konto? <Link to="/login">Zaloguj się</Link>
        </p>
      </div>
    </div>
  );
}
