// apps/web/src/pages/UploadPage.tsx
import { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { uploadsApi, tracksApi } from '../lib/api';
import { extractWaveformPeaks } from '../hooks/useAudioPlayer';
import { WaveformCanvas } from '../components/player/WaveformCanvas';
import styles from './UploadPage.module.css';

const GENRES = ['LIQUID_DNB','NEUROFUNK','TECH_DNB','JUMP_UP','DARKSTEP','ROLLERS','HALFSTEP','OTHER'];
const GENRE_LABELS: Record<string,string> = {
  LIQUID_DNB:'Liquid DnB', NEUROFUNK:'Neurofunk', TECH_DNB:'Tech DnB',
  JUMP_UP:'Jump Up', DARKSTEP:'Darkstep', ROLLERS:'Rollers', HALFSTEP:'Halfstep', OTHER:'Inne',
};

export function UploadPage() {
  const navigate = useNavigate();
  const audioInput  = useRef<HTMLInputElement>(null);
  const coverInput  = useRef<HTMLInputElement>(null);
  const dropZoneRef = useRef<HTMLDivElement>(null);

  const [audioFile,  setAudioFile]  = useState<File|null>(null);
  const [coverFile,  setCoverFile]  = useState<File|null>(null);
  const [peaks,      setPeaks]      = useState<number[]>([]);
  const [duration,   setDuration]   = useState(0);
  const [dragging,   setDragging]   = useState(false);
  const [step,       setStep]       = useState<'drop'|'meta'>('drop');
  const [uploading,  setUploading]  = useState(false);
  const [error,      setError]      = useState('');

  const [form, setForm] = useState({
    title: '', genre: 'LIQUID_DNB', bpm: '', country: 'PL', description: '',
  });

  async function handleAudioFile(file: File) {
    if (!file.type.startsWith('audio/')) { setError('Tylko pliki audio (MP3, WAV, FLAC)'); return; }
    setAudioFile(file);
    setError('');

    // Extract real waveform peaks + duration via Web Audio
    try {
      const [extractedPeaks] = await Promise.all([
        extractWaveformPeaks(file, 200),
      ]);
      setPeaks(extractedPeaks);

      // Get duration via AudioElement
      const url = URL.createObjectURL(file);
      const audio = new Audio(url);
      audio.addEventListener('loadedmetadata', () => {
        setDuration(Math.round(audio.duration));
        URL.revokeObjectURL(url);
      });
      audio.load();
    } catch (e) {
      console.warn('Waveform extraction failed, using synthetic', e);
    }
    setStep('meta');
    setForm(f => ({ ...f, title: file.name.replace(/\.[^.]+$/, '').replace(/[-_]/g,' ') }));
  }

  function onDrop(e: React.DragEvent) {
    e.preventDefault(); setDragging(false);
    const file = e.dataTransfer.files[0];
    if (file) handleAudioFile(file);
  }

  async function handleSubmit() {
    if (!audioFile) return;
    setUploading(true); setError('');
    try {
      const [audioUrl, coverUrl] = await Promise.all([
        uploadsApi.audio(audioFile),
        coverFile ? uploadsApi.cover(coverFile) : Promise.resolve(undefined),
      ]);

      const track = await tracksApi.create({
        title:        form.title,
        genre:        form.genre,
        bpm:          form.bpm ? Number(form.bpm) : undefined,
        country:      form.country || undefined,
        description:  form.description || undefined,
        audioUrl,
        coverUrl,
        duration,
        waveformData: peaks.length ? peaks : undefined,
      });

      navigate(`/track/${track.id}`);
    } catch (e: any) {
      setError(e.response?.data?.error ?? 'Upload nie udany. Spróbuj ponownie.');
    } finally {
      setUploading(false);
    }
  }

  return (
    <div className={styles.page}>
      <div className={styles.header}>
        <h1>Wgraj track</h1>
        <p>MP3, WAV, FLAC, AIFF · max 100 MB</p>
      </div>

      {/* ── Step 1: Drop zone ── */}
      {step === 'drop' && (
        <div
          ref={dropZoneRef}
          className={`${styles.dropZone} ${dragging ? styles.dragOver : ''}`}
          onDragOver={e => { e.preventDefault(); setDragging(true); }}
          onDragLeave={() => setDragging(false)}
          onDrop={onDrop}
          onClick={() => audioInput.current?.click()}
        >
          <div className={styles.dropIcon}>🎵</div>
          <p>Przeciągnij plik audio tutaj</p>
          <span>lub kliknij, żeby wybrać</span>
          <input ref={audioInput} type="file" accept="audio/*" hidden
            onChange={e => e.target.files?.[0] && handleAudioFile(e.target.files[0])} />
        </div>
      )}

      {/* ── Step 2: Metadata form ── */}
      {step === 'meta' && audioFile && (
        <div className={styles.form}>
          {/* Audio preview */}
          <div className={styles.audioPreview}>
            <div className={styles.audioName}>🎵 {audioFile.name}</div>
            <div className={styles.wfWrap}>
              <WaveformCanvas peaks={peaks} progress={0} colors={['#33e4ff','#7b5cff']} height={36} />
            </div>
            <div className={styles.audioDur}>{fmt(duration)}</div>
          </div>

          <div className={styles.row}>
            <label className={styles.field}>
              <span>Tytuł *</span>
              <input value={form.title} onChange={e => setForm(f => ({...f,title:e.target.value}))}
                placeholder="Tytuł tracku" />
            </label>
            <label className={styles.field}>
              <span>Gatunek *</span>
              <select value={form.genre} onChange={e => setForm(f => ({...f,genre:e.target.value}))}>
                {GENRES.map(g => <option key={g} value={g}>{GENRE_LABELS[g]}</option>)}
              </select>
            </label>
          </div>

          <div className={styles.row}>
            <label className={styles.field}>
              <span>BPM</span>
              <input type="number" min={100} max={240} value={form.bpm}
                onChange={e => setForm(f => ({...f,bpm:e.target.value}))}
                placeholder="174" />
            </label>
            <label className={styles.field}>
              <span>Kraj</span>
              <input maxLength={2} value={form.country}
                onChange={e => setForm(f => ({...f,country:e.target.value.toUpperCase()}))}
                placeholder="PL" />
            </label>
          </div>

          <label className={styles.field}>
            <span>Opis</span>
            <textarea rows={3} value={form.description}
              onChange={e => setForm(f => ({...f,description:e.target.value}))}
              placeholder="Powiedz coś o tym tracku…" />
          </label>

          {/* Cover upload */}
          <label className={styles.coverRow} onClick={() => coverInput.current?.click()}>
            {coverFile
              ? <img src={URL.createObjectURL(coverFile)} alt="cover" className={styles.coverThumb} />
              : <div className={styles.coverPlaceholder}>🖼 Dodaj okładkę (opcjonalne)</div>}
            <input ref={coverInput} type="file" accept="image/*" hidden
              onChange={e => e.target.files?.[0] && setCoverFile(e.target.files[0])} />
          </label>

          {error && <div className={styles.error}>{error}</div>}

          <div className={styles.formActions}>
            <button className={styles.backBtn} onClick={() => { setStep('drop'); setAudioFile(null); setPeaks([]); }}>
              ← Cofnij
            </button>
            <button
              className={styles.submitBtn}
              onClick={handleSubmit}
              disabled={!form.title || uploading}
            >
              {uploading ? 'Wysyłanie…' : '⬆ Opublikuj track'}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

function fmt(s: number) {
  s = Math.max(0, Math.round(s));
  return `${Math.floor(s/60)}:${String(s%60).padStart(2,'0')}`;
}
