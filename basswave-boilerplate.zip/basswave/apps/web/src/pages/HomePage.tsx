// apps/web/src/pages/HomePage.tsx
import { useQuery } from '@tanstack/react-query';
import { tracksApi } from '../lib/api';
import { TrackCard }  from '../components/tracks/TrackCard';
import { usePlayerStore } from '../lib/playerStore';
import styles from './HomePage.module.css';

const GENRES = ['LIQUID_DNB','NEUROFUNK','TECH_DNB','JUMP_UP','DARKSTEP'];
const GENRE_LABELS: Record<string,string> = {
  LIQUID_DNB:'Liquid', NEUROFUNK:'Neurofunk', TECH_DNB:'Tech DnB',
  JUMP_UP:'Jump Up', DARKSTEP:'Darkstep',
};

export function HomePage() {
  const { data: tracks = [], isLoading } = useQuery({
    queryKey: ['tracks','home'],
    queryFn:  () => tracksApi.list({ limit:'20' }),
  });

  const store = usePlayerStore();

  return (
    <div>
      {/* Featured */}
      {tracks[0] && (
        <div className={styles.featured}>
          <div className={styles.featArt} />
          <div className={styles.featInfo}>
            <div className={styles.featLabel}>FEATURED</div>
            <h2>{tracks[0].title}</h2>
            <p>{tracks[0].artist?.displayName} · {tracks[0].genre?.replace('_',' ')} · {tracks[0].bpm} BPM</p>
          </div>
          <button className={styles.featBtn} onClick={() => store.play(tracks[0], tracks)}>
            ▶ Odtwórz
          </button>
        </div>
      )}

      {/* Genre pills */}
      <div className={styles.genreRow}>
        {GENRES.map(g => (
          <a key={g} href={`/discover?genre=${g}`} className={styles.pill}>
            {GENRE_LABELS[g]}
          </a>
        ))}
      </div>

      {/* Track grid */}
      <div className={styles.sectionHead}>
        <div>
          <h2>Dla Ciebie</h2>
          <span className={styles.sub}>Nowe z Twojej sceny · {tracks.length} tracków</span>
        </div>
        <a href="/discover" className={styles.seeAll}>POKAŻ WIĘCEJ →</a>
      </div>

      {isLoading ? (
        <div className={styles.loading}>Ładowanie…</div>
      ) : (
        <div className={styles.grid}>
          {tracks.map((t: any) => (
            <TrackCard key={t.id} track={t} queue={tracks} />
          ))}
        </div>
      )}
    </div>
  );
}
