// apps/web/src/pages/TrackPage.tsx
import { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { tracksApi } from '../lib/api';
import { usePlayerStore } from '../lib/playerStore';
import { useAuthStore } from '../lib/authStore';
import { WaveformCanvas } from '../components/player/WaveformCanvas';
import styles from './TrackPage.module.css';

const GENRE_COLORS: Record<string,[string,string]> = {
  LIQUID_DNB:['#33e4ff','#7b5cff'], NEUROFUNK:['#ff3366','#7b5cff'],
  TECH_DNB:['#ffaa00','#ff3366'],   DARKSTEP:['#7b5cff','#33e4ff'],
  JUMP_UP:['#ff6b35','#ffaa00'],    ROLLERS:['#4cffb2','#33e4ff'],
  HALFSTEP:['#33e4ff','#4cffb2'],   OTHER:['#9ba0bd','#6b7090'],
};

function fmt(s: number) {
  s = Math.max(0, Math.round(s));
  return `${Math.floor(s/60)}:${String(s%60).padStart(2,'0')}`;
}

export function TrackPage() {
  const { id } = useParams<{ id: string }>();
  const store  = usePlayerStore();
  const { user } = useAuthStore();
  const qc     = useQueryClient();
  const [comment, setComment] = useState('');

  const { data: track, isLoading } = useQuery({
    queryKey: ['track', id],
    queryFn:  () => tracksApi.get(id!),
  });

  const likeMutation = useMutation({
    mutationFn: () => tracksApi.like(id!),
    onSuccess:  () => qc.invalidateQueries({ queryKey: ['track', id] }),
  });

  const commentMutation = useMutation({
    mutationFn: (body: string) => tracksApi.comment(id!, body),
    onSuccess: () => {
      setComment('');
      qc.invalidateQueries({ queryKey: ['track', id] });
    },
  });

  if (isLoading) return <div className={styles.loading}>Ładowanie…</div>;
  if (!track)    return <div className={styles.loading}>Nie znaleziono tracku.</div>;

  const colors   = GENRE_COLORS[track.genre] ?? ['#33e4ff','#7b5cff'];
  const isActive = store.queue[store.currentIdx]?.id === track.id;
  const isPlaying = isActive && store.playing;

  function handlePlay() {
    if (isActive) { store.toggle(); }
    else { store.play(track); }
  }

  return (
    <div className={styles.page}>
      {/* Hero */}
      <div className={styles.hero}>
        <div className={styles.cover} style={{ background: `linear-gradient(135deg,${colors[0]},${colors[1]})` }}>
          {track.coverUrl && <img src={track.coverUrl} alt={track.title} />}
        </div>

        <div className={styles.heroInfo}>
          <div className={styles.genreTag}>{track.genre?.replace(/_/g,' ')}</div>
          <h1>{track.title}</h1>
          <Link to={`/artist/${track.artist?.username}`} className={styles.artistLink}>
            {track.artist?.displayName}
          </Link>

          <div className={styles.metaTags}>
            {track.bpm && <span className={styles.tag}>{track.bpm} BPM</span>}
            {track.key && <span className={styles.tag}>{track.key}</span>}
            {track.country && <span className={styles.tag}>{track.country}</span>}
            <span className={styles.tag}>{fmt(track.duration)}</span>
          </div>

          <div className={styles.statsRow}>
            <span>▶ {track.plays?.toLocaleString()} odtworzeń</span>
            <span>♥ {track._count?.likes ?? 0} lajków</span>
            <span>💬 {track.comments?.length ?? 0} komentarzy</span>
          </div>
        </div>
      </div>

      {/* Waveform player */}
      <div className={styles.playerSection}>
        <button className={styles.bigPlay} onClick={handlePlay}>
          {isPlaying ? '⏸' : '▶'}
        </button>
        <div className={styles.wfWrap}>
          <WaveformCanvas
            peaks={track.waveformData}
            progress={isActive ? store.progress : 0}
            colors={colors}
            onSeek={p => { store.play(track); store.seek(p); }}
            height={48}
          />
        </div>
        <span className={styles.dur}>{fmt(track.duration)}</span>
      </div>

      {/* Actions */}
      <div className={styles.actions}>
        <button
          className={`${styles.actionBtn} ${track.likedByMe ? styles.liked : ''}`}
          onClick={() => likeMutation.mutate()}
          disabled={!user}
        >
          {track.likedByMe ? '♥' : '♡'} {track._count?.likes ?? 0} Lajkuj
        </button>
        <a href={track.audioUrl} download className={styles.actionBtn}>
          ⬇ Pobierz
        </a>
        <button className={styles.actionBtn} onClick={() => navigator.share?.({ title: track.title, url: location.href })}>
          ↗ Udostępnij
        </button>
      </div>

      {/* Description */}
      {track.description && (
        <div className={styles.description}>{track.description}</div>
      )}

      {/* Comments */}
      <div className={styles.commentsSection}>
        <h2>Komentarze <span>({track.comments?.length ?? 0})</span></h2>

        {user ? (
          <div className={styles.commentForm}>
            <input
              value={comment}
              onChange={e => setComment(e.target.value)}
              placeholder="Dodaj komentarz…"
              onKeyDown={e => {
                if (e.key === 'Enter' && comment.trim()) commentMutation.mutate(comment.trim());
              }}
            />
            <button
              onClick={() => comment.trim() && commentMutation.mutate(comment.trim())}
              disabled={!comment.trim() || commentMutation.isPending}
              className={styles.commentBtn}
            >
              {commentMutation.isPending ? '…' : 'Wyślij'}
            </button>
          </div>
        ) : (
          <p className={styles.loginPrompt}>
            <Link to="/login">Zaloguj się</Link>, żeby komentować.
          </p>
        )}

        <div className={styles.commentList}>
          {track.comments?.map((c: any) => (
            <div key={c.id} className={styles.comment}>
              <div className={styles.commentAvatar}>
                {c.user?.displayName?.[0]?.toUpperCase()}
              </div>
              <div className={styles.commentBody}>
                <div className={styles.commentMeta}>
                  <strong>{c.user?.displayName}</strong>
                  <span>@{c.user?.username}</span>
                  {c.timestamp != null && (
                    <span className={styles.timestamp}>⏱ {fmt(c.timestamp)}</span>
                  )}
                </div>
                <p>{c.body}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
