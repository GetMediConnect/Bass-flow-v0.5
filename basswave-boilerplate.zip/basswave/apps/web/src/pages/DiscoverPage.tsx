// apps/web/src/pages/DiscoverPage.tsx
import { useSearchParams } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { tracksApi } from '../lib/api';
import { TrackCard }  from '../components/tracks/TrackCard';
import styles from './DiscoverPage.module.css';

const GENRES = [
  {value:'',          label:'Wszystko'},
  {value:'LIQUID_DNB',label:'Liquid'},
  {value:'NEUROFUNK', label:'Neurofunk'},
  {value:'TECH_DNB',  label:'Tech DnB'},
  {value:'JUMP_UP',   label:'Jump Up'},
  {value:'DARKSTEP',  label:'Darkstep'},
  {value:'ROLLERS',   label:'Rollers'},
  {value:'HALFSTEP',  label:'Halfstep'},
];

export function DiscoverPage() {
  const [params, setParams] = useSearchParams();
  const q     = params.get('q')     ?? '';
  const genre = params.get('genre') ?? '';

  const { data: tracks = [], isLoading } = useQuery({
    queryKey: ['tracks','discover', q, genre],
    queryFn:  () => tracksApi.list({ ...(q && {q}), ...(genre && {genre}), limit:'40' }),
  });

  return (
    <div>
      <div className={styles.header}>
        <h1>Odkrywaj</h1>
        <input
          className={styles.search}
          placeholder="Szukaj…"
          defaultValue={q}
          onChange={e => setParams({ q: e.target.value, ...(genre && { genre }) })}
        />
      </div>

      <div className={styles.filters}>
        {GENRES.map(g => (
          <button
            key={g.value}
            className={`${styles.pill} ${genre===g.value ? styles.active : ''}`}
            onClick={() => setParams({ ...(q && {q}), genre: g.value })}
          >
            {g.label}
          </button>
        ))}
      </div>

      <div className={styles.meta}>{isLoading ? '…' : `${tracks.length} tracków`}</div>

      {isLoading ? (
        <div className={styles.loading}>Ładowanie…</div>
      ) : tracks.length === 0 ? (
        <div className={styles.empty}>Brak wyników. Spróbuj innej frazy.</div>
      ) : (
        <div className={styles.grid}>
          {tracks.map((t: any) => <TrackCard key={t.id} track={t} queue={tracks} />)}
        </div>
      )}
    </div>
  );
}
