// apps/api/src/index.ts
import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import { tracksRouter }   from './routes/tracks.js';
import { usersRouter }    from './routes/users.js';
import { authRouter }     from './routes/auth.js';
import { uploadsRouter }  from './routes/uploads.js';
import { errorHandler }   from './middleware/errorHandler.js';

const app  = express();
const PORT = process.env.PORT || 3001;

// ── Middleware ──────────────────────────────────────────
app.use(cors({ origin: process.env.WEB_URL || 'http://localhost:5173', credentials: true }));
app.use(express.json());

// ── Routes ──────────────────────────────────────────────
app.use('/api/auth',    authRouter);
app.use('/api/users',   usersRouter);
app.use('/api/tracks',  tracksRouter);
app.use('/api/uploads', uploadsRouter);

app.get('/health', (_req, res) => res.json({ ok: true, version: '0.1.0' }));

// ── Error handler ───────────────────────────────────────
app.use(errorHandler);

app.listen(PORT, () => {
  console.log(`🎛️  BassWave API running on http://localhost:${PORT}`);
});
