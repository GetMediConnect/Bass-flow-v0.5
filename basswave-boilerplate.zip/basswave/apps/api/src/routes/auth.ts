// apps/api/src/routes/auth.ts
import { Router } from 'express';
import { z } from 'zod';
import jwt from 'jsonwebtoken';
import { prisma } from '../lib/prisma.js';
import { supabase } from '../lib/supabase.js';

export const authRouter = Router();

const RegisterSchema = z.object({
  email:       z.string().email(),
  password:    z.string().min(8),
  username:    z.string().min(3).max(30).regex(/^[a-z0-9_]+$/),
  displayName: z.string().min(1).max(60),
  country:     z.string().length(2).optional(),
});

const LoginSchema = z.object({
  email:    z.string().email(),
  password: z.string(),
});

// ── POST /api/auth/register ──────────────────────────────
authRouter.post('/register', async (req, res, next) => {
  try {
    const body = RegisterSchema.parse(req.body);

    // 1. Create Supabase Auth user
    const { data: authData, error: authError } = await supabase.auth.admin.createUser({
      email: body.email, password: body.password, email_confirm: true,
    });
    if (authError) return res.status(400).json({ error: authError.message });

    // 2. Create DB profile
    const user = await prisma.user.create({
      data: {
        id:          authData.user.id,
        email:       body.email,
        username:    body.username,
        displayName: body.displayName,
        country:     body.country,
      },
    });

    const token = signToken(user.id);
    res.status(201).json({ token, user: safeUser(user) });
  } catch (e) { next(e); }
});

// ── POST /api/auth/login ─────────────────────────────────
authRouter.post('/login', async (req, res, next) => {
  try {
    const { email, password } = LoginSchema.parse(req.body);

    const { data, error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) return res.status(401).json({ error: 'Invalid credentials' });

    const user = await prisma.user.findUnique({ where: { id: data.user.id } });
    if (!user) return res.status(404).json({ error: 'User not found' });

    const token = signToken(user.id);
    res.json({ token, user: safeUser(user) });
  } catch (e) { next(e); }
});

// ── Helpers ──────────────────────────────────────────────
function signToken(userId: string) {
  return jwt.sign({ sub: userId }, process.env.JWT_SECRET!, { expiresIn: '30d' });
}

function safeUser(u: { id: string; email: string; username: string; displayName: string; avatarUrl: string | null; country: string | null }) {
  const { email: _e, ...pub } = u;
  return pub;
}
