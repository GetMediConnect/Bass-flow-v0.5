// apps/api/src/routes/tracks.ts
import { Router } from 'express';
import { z } from 'zod';
import { prisma } from '../lib/prisma.js';
import { requireAuth, optionalAuth, AuthRequest } from '../middleware/auth.js';

export const tracksRouter = Router();

const TrackCreateSchema = z.object({
  title:       z.string().min(1).max(120),
  bpm:         z.number().int().min(100).max(240).optional(),
  key:         z.string().max(5).optional(),
  genre:       z.enum(['LIQUID_DNB','NEUROFUNK','TECH_DNB','JUMP_UP','DARKSTEP','ROLLERS','HALFSTEP','OTHER']),
  country:     z.string().length(2).optional(),
  description: z.string().max(1000).optional(),
  audioUrl:    z.string().url(),
  coverUrl:    z.string().url().optional(),
  duration:    z.number().int().positive(),
  waveformData:z.array(z.number()).optional(),
  tags:        z.array(z.string()).max(10).optional(),
  labelId:     z.string().optional(),
});

// ── GET /api/tracks  (list + filter) ────────────────────
tracksRouter.get('/', optionalAuth, async (req: AuthRequest, res, next) => {
  try {
    const { genre, country, q, limit = '20', offset = '0', artistId } = req.query as Record<string,string>;

    const tracks = await prisma.track.findMany({
      where: {
        isPublic: true,
        ...(genre     && { genre: genre as any }),
        ...(country   && { country }),
        ...(artistId  && { artistId }),
        ...(q && {
          OR: [
            { title:  { contains: q, mode: 'insensitive' } },
            { artist: { displayName: { contains: q, mode: 'insensitive' } } },
          ],
        }),
      },
      include: {
        artist: { select: { id:true, username:true, displayName:true, avatarUrl:true, country:true } },
        tags:   { include: { tag: { select: { name:true } } } },
        _count: { select: { likes:true, comments:true } },
        ...(req.userId && {
          likes: { where: { userId: req.userId }, select: { id:true } },
        }),
      },
      orderBy: { createdAt: 'desc' },
      take:   Math.min(Number(limit),  100),
      skip:   Math.max(Number(offset), 0),
    });

    res.json(tracks.map(t => ({
      ...t,
      likedByMe: req.userId ? t.likes?.length > 0 : false,
      likes: undefined,
    })));
  } catch (e) { next(e); }
});

// ── GET /api/tracks/:id ──────────────────────────────────
tracksRouter.get('/:id', optionalAuth, async (req: AuthRequest, res, next) => {
  try {
    const track = await prisma.track.findUnique({
      where: { id: req.params.id },
      include: {
        artist:   { select: { id:true, username:true, displayName:true, avatarUrl:true } },
        tags:     { include: { tag: true } },
        comments: {
          orderBy: { createdAt: 'asc' },
          include: { user: { select: { id:true, username:true, displayName:true, avatarUrl:true } } },
        },
        _count: { select: { likes:true } },
      },
    });
    if (!track) return res.status(404).json({ error: 'Track not found' });

    // increment play count (fire-and-forget)
    prisma.track.update({ where: { id: track.id }, data: { plays: { increment: 1 } } }).catch(() => {});

    res.json(track);
  } catch (e) { next(e); }
});

// ── POST /api/tracks ─────────────────────────────────────
tracksRouter.post('/', requireAuth, async (req: AuthRequest, res, next) => {
  try {
    const body = TrackCreateSchema.parse(req.body);
    const slug = slugify(body.title) + '-' + Date.now().toString(36);

    const track = await prisma.track.create({
      data: {
        ...body,
        slug,
        artistId:    req.userId!,
        waveformData: body.waveformData ?? undefined,
        tags: body.tags?.length ? {
          create: body.tags.map(name => ({
            tag: { connectOrCreate: { where: { name }, create: { name } } },
          })),
        } : undefined,
      },
      include: {
        artist: { select: { id:true, username:true, displayName:true } },
        tags:   { include: { tag: true } },
      },
    });

    res.status(201).json(track);
  } catch (e) { next(e); }
});

// ── DELETE /api/tracks/:id ───────────────────────────────
tracksRouter.delete('/:id', requireAuth, async (req: AuthRequest, res, next) => {
  try {
    const track = await prisma.track.findUnique({ where: { id: req.params.id } });
    if (!track)               return res.status(404).json({ error: 'Not found' });
    if (track.artistId !== req.userId) return res.status(403).json({ error: 'Forbidden' });
    await prisma.track.delete({ where: { id: req.params.id } });
    res.json({ ok: true });
  } catch (e) { next(e); }
});

// ── POST /api/tracks/:id/like ────────────────────────────
tracksRouter.post('/:id/like', requireAuth, async (req: AuthRequest, res, next) => {
  try {
    const existing = await prisma.like.findUnique({
      where: { userId_trackId: { userId: req.userId!, trackId: req.params.id } },
    });

    if (existing) {
      await prisma.like.delete({ where: { id: existing.id } });
      res.json({ liked: false });
    } else {
      await prisma.like.create({ data: { userId: req.userId!, trackId: req.params.id } });
      res.json({ liked: true });
    }
  } catch (e) { next(e); }
});

// ── POST /api/tracks/:id/comments ───────────────────────
tracksRouter.post('/:id/comments', requireAuth, async (req: AuthRequest, res, next) => {
  try {
    const { body, timestamp } = z.object({
      body:      z.string().min(1).max(500),
      timestamp: z.number().int().nonnegative().optional(),
    }).parse(req.body);

    const comment = await prisma.comment.create({
      data: { body, timestamp, userId: req.userId!, trackId: req.params.id },
      include: { user: { select: { id:true, username:true, displayName:true, avatarUrl:true } } },
    });
    res.status(201).json(comment);
  } catch (e) { next(e); }
});

// ── Helpers ──────────────────────────────────────────────
function slugify(str: string) {
  return str.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
}
