// apps/api/src/routes/users.ts
import { Router } from 'express';
import { prisma } from '../lib/prisma.js';
import { requireAuth, optionalAuth, AuthRequest } from '../middleware/auth.js';

export const usersRouter = Router();

// ── GET /api/users/:username ─────────────────────────────
usersRouter.get('/:username', optionalAuth, async (req: AuthRequest, res, next) => {
  try {
    const user = await prisma.user.findUnique({
      where: { username: req.params.username },
      include: {
        tracks: {
          where: { isPublic: true },
          orderBy: { createdAt: 'desc' },
          take: 10,
          include: { _count: { select: { likes:true } } },
        },
        _count: { select: { tracks:true, followers:true, following:true } },
      },
    });
    if (!user) return res.status(404).json({ error: 'User not found' });
    const { email: _e, ...safe } = user as any;
    res.json(safe);
  } catch (e) { next(e); }
});

// ── GET /api/users/me ────────────────────────────────────
usersRouter.get('/me/profile', requireAuth, async (req: AuthRequest, res, next) => {
  try {
    const user = await prisma.user.findUnique({
      where: { id: req.userId },
      include: { _count: { select: { tracks:true, followers:true, following:true } } },
    });
    if (!user) return res.status(404).json({ error: 'Not found' });
    res.json(user);
  } catch (e) { next(e); }
});

// ── POST /api/users/:id/follow ───────────────────────────
usersRouter.post('/:id/follow', requireAuth, async (req: AuthRequest, res, next) => {
  try {
    if (req.params.id === req.userId) return res.status(400).json({ error: "Can't follow yourself" });
    const existing = await prisma.follow.findUnique({
      where: { followerId_followingId: { followerId: req.userId!, followingId: req.params.id } },
    });
    if (existing) {
      await prisma.follow.delete({ where: { followerId_followingId: { followerId: req.userId!, followingId: req.params.id } } });
      res.json({ following: false });
    } else {
      await prisma.follow.create({ data: { followerId: req.userId!, followingId: req.params.id } });
      res.json({ following: true });
    }
  } catch (e) { next(e); }
});
