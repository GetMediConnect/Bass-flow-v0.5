// apps/api/src/routes/uploads.ts
import { Router } from 'express';
import multer from 'multer';
import { requireAuth, AuthRequest } from '../middleware/auth.js';
import { uploadAudio, uploadCover } from '../lib/supabase.js';

export const uploadsRouter = Router();

const storage = multer.memoryStorage();

const audioUpload = multer({
  storage,
  limits: { fileSize: 100 * 1024 * 1024 }, // 100 MB
  fileFilter: (_req, file, cb) => {
    if (['audio/mpeg','audio/wav','audio/x-wav','audio/flac','audio/aiff'].includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('Only MP3, WAV, FLAC, AIFF allowed'));
    }
  },
});

const imageUpload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 }, // 5 MB
  fileFilter: (_req, file, cb) => {
    if (['image/jpeg','image/png','image/webp'].includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('Only JPG, PNG, WEBP allowed'));
    }
  },
});

// ── POST /api/uploads/audio ──────────────────────────────
uploadsRouter.post('/audio', requireAuth, audioUpload.single('file'), async (req: AuthRequest, res, next) => {
  try {
    if (!req.file) return res.status(400).json({ error: 'No file provided' });
    const url = await uploadAudio(req.file.buffer, req.file.originalname, req.file.mimetype);
    res.json({ url });
  } catch (e) { next(e); }
});

// ── POST /api/uploads/cover ──────────────────────────────
uploadsRouter.post('/cover', requireAuth, imageUpload.single('file'), async (req: AuthRequest, res, next) => {
  try {
    if (!req.file) return res.status(400).json({ error: 'No file provided' });
    const url = await uploadCover(req.file.buffer, req.file.originalname, req.file.mimetype);
    res.json({ url });
  } catch (e) { next(e); }
});
