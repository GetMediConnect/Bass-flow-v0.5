// apps/api/src/lib/supabase.ts
import { createClient } from '@supabase/supabase-js';

export const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_KEY!  // service role key – server only!
);

const AUDIO_BUCKET  = 'tracks-audio';
const COVERS_BUCKET = 'tracks-covers';

// ── Upload audio file ────────────────────────────────────
export async function uploadAudio(
  buffer: Buffer,
  filename: string,
  mimeType: string
): Promise<string> {
  const path = `${Date.now()}-${filename}`;
  const { error } = await supabase.storage
    .from(AUDIO_BUCKET)
    .upload(path, buffer, { contentType: mimeType, upsert: false });
  if (error) throw new Error(`Audio upload failed: ${error.message}`);
  return supabase.storage.from(AUDIO_BUCKET).getPublicUrl(path).data.publicUrl;
}

// ── Upload cover image ───────────────────────────────────
export async function uploadCover(
  buffer: Buffer,
  filename: string,
  mimeType: string
): Promise<string> {
  const path = `${Date.now()}-${filename}`;
  const { error } = await supabase.storage
    .from(COVERS_BUCKET)
    .upload(path, buffer, { contentType: mimeType, upsert: false });
  if (error) throw new Error(`Cover upload failed: ${error.message}`);
  return supabase.storage.from(COVERS_BUCKET).getPublicUrl(path).data.publicUrl;
}

// ── Delete file ──────────────────────────────────────────
export async function deleteFile(bucket: string, url: string) {
  const path = url.split(`${bucket}/`)[1];
  if (!path) return;
  await supabase.storage.from(bucket).remove([path]);
}
