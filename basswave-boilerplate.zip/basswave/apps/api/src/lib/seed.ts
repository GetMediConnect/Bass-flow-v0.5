// apps/api/src/lib/seed.ts
// Uruchom: npm run db:seed -w apps/api
import 'dotenv/config';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Seeding BassWave database…');

  // Users
  const maduki = await prisma.user.upsert({
    where: { email: 'maduki@basswave.io' },
    update: {},
    create: {
      id:          'seed-maduki',
      email:       'maduki@basswave.io',
      username:    'djmaduki',
      displayName: 'DJ Maduki',
      country:     'PL',
      bio:         'Liquid DnB z Polski 🇵🇱 | BassWave founder',
    },
  });

  const kameleon = await prisma.user.upsert({
    where: { email: 'kameleon@basswave.io' },
    update: {},
    create: {
      id:          'seed-kameleon',
      email:       'kameleon@basswave.io',
      username:    'kameleon',
      displayName: 'Kameleon',
      country:     'PL',
    },
  });

  // Tracks
  await prisma.track.upsert({
    where: { slug: 'milosc-w-czasach-klik-seed' },
    update: {},
    create: {
      title:       'Miłość w Czasach Klik',
      slug:        'milosc-w-czasach-klik-seed',
      bpm:         174,
      genre:       'LIQUID_DNB',
      country:     'PL',
      duration:    252,
      description: 'Debiutancki liquid DnB track. Emocje, bas i 174 BPM.',
      audioUrl:    'https://example.com/audio/milosc.mp3', // zastąp prawdziwym
      artistId:    maduki.id,
      tags: {
        create: [
          { tag: { connectOrCreate: { where: { name: 'liquid' }, create: { name: 'liquid' } } } },
          { tag: { connectOrCreate: { where: { name: 'emotional' }, create: { name: 'emotional' } } } },
        ],
      },
    },
  });

  await prisma.track.upsert({
    where: { slug: 'beton-sunrise-seed' },
    update: {},
    create: {
      title:    'Beton Sunrise',
      slug:     'beton-sunrise-seed',
      bpm:      176,
      genre:    'TECH_DNB',
      country:  'PL',
      duration: 404,
      audioUrl: 'https://example.com/audio/beton.mp3',
      artistId: kameleon.id,
    },
  });

  console.log('✅ Seed done!');
  console.log(`   Users: ${await prisma.user.count()}`);
  console.log(`   Tracks: ${await prisma.track.count()}`);
}

main()
  .catch(e => { console.error(e); process.exit(1); })
  .finally(() => prisma.$disconnect());
